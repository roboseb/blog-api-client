
True Type Font: Pixel Dingbats-7 version 1.0


EULA
-==-
The font Pixel Dingbats-7 is freeware.


DESCRIPTION
-=========-
Collection of symbols 8*8 pixels. There are patterns, chess pieces, cards, icons etc.

Files in pixel_dingbats-7.zip:
       	readme.txt     				this file;
        pixel_dingbats-7.ttf			regular style;
	pixel_dingbats-7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 19 2013